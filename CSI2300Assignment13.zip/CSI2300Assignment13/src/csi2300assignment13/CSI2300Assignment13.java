/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package csi2300assignment13;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author sstan
 */
public class CSI2300Assignment13 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
      String inputfile; 
        inputfile = "inputFile.txt";
      String outputFile = "outputFile.txt"; 
      
    Map<String, Integer> wordCounts = new HashMap<>();
        String file = null;
    try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                            String line;
        while (null != (line = br.readLine())) {
                String word = line.trim().toLowerCase();
                wordCounts.put(word, wordCounts.getOrDefault(word, 0) + 1);
                            }
    
    } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
    }
    
    try (FileWriter write = new FileWriter(outputFile)) {
        for (Map.Entry<String, Integer> entry : wordCounts.entrySet()) {
                write.write(entry.getKey() + " " + entry.getValue() + "\n");
    } 
    } catch (IOException ex) {
        System.err.println("Error: " + ex.getMessage()); 
    }
    
    System.out.println("Word counts have been written to " + outputFile);
}
}

